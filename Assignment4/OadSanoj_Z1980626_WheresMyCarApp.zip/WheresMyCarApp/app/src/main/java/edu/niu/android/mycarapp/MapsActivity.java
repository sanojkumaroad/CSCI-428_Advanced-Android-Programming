package edu.niu.android.mycarapp;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import edu.niu.android.mycarapp.databinding.ActivityMapsBinding;

/*************************************************
 * Class Name:  MapsActivity.java                *
 * Purpose:     This class implements the maps   *
 *              on the screen and implements the *
 *              click listeners to save or       *
 *              retrieve location parked car.    *
 *************************************************/
public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    // Constant for location permission request code
    private static final int LOCATION_REQUEST_CODE = 101;
    SharedPreferences.Editor editor = null;
    // SharedPreferences for persistent data storage
    private SharedPreferences saved_location = null;
    // GoogleMap object for displaying maps
    private GoogleMap mMap = null;


    /*
     * Method:      onCreate
     * Description: This method is called when the activity is first created.
     *              It sets up the user interface, initializes SharedPreferences,
     *              and retrieves the SupportMapFragment.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set fullscreen mode
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 0);

        // Inflate layout using View Binding
        edu.niu.android.mycarapp.databinding.ActivityMapsBinding binding =
                ActivityMapsBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());

        // Initialize SharedPreferences for persistent data
        saved_location = getSharedPreferences("MyPreferences", Context.MODE_PRIVATE);

        // Obtain the Support MapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment)
                getSupportFragmentManager().findFragmentById(R.id.map);

        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    /*** Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */

    /*
     * Method:      onMapReady
     * Description: This callback is triggered when the map is ready to be used.
     *              It sets up the map and displays the user's current location if permission
     *              is granted.
     */
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        int permission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);

        if (permission == PackageManager.PERMISSION_GRANTED) {
            googleMap.setMyLocationEnabled(true);
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);

            if (location != null) {
                LatLng locationLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                CameraUpdate update = CameraUpdateFactory.newLatLngZoom(locationLatLng, 15f);
                googleMap.moveCamera(update);
            }
        } else {
            requestPermission();
        }
    }

    /*
     * Method: requestPermission
     * Description: Requests location permission from the user.
     */
    protected void requestPermission() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                MapsActivity.LOCATION_REQUEST_CODE);
    }

    /*
     * Method:      onRequestPermissionsResult
     * Description: Handles the result of the permission request.
     *              If permission is granted, it initializes the map.
     */
    @Override
    public void onRequestPermissionsResult(
            int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_REQUEST_CODE) {
            if (grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(this, "Unable to show location - permission required",
                        Toast.LENGTH_LONG).show();
            } else {
                SupportMapFragment mapFragment = (SupportMapFragment)
                        getSupportFragmentManager().findFragmentById(R.id.map);

                if (mapFragment != null) {
                    mapFragment.getMapAsync(this);
                }
            }
        }
    }

    /*
     * Method:      saveLocation
     * Description: Saves the current location as the car's location in SharedPreferences.
     */
    public void saveLocation(View view) {
        int permission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);

        if (permission == PackageManager.PERMISSION_GRANTED) {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);

            // Current location is read and being saved
            if (location != null) {
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();

                // Saving Car Location in Persistent Data
                editor = saved_location.edit();
                editor.putString("latitude", String.valueOf(latitude));
                editor.putString("longitude", String.valueOf(longitude));
                editor.apply();

                // Display saved location of the car message
                String msg = "Car location saved at lat: " + latitude + ", long: " + longitude;
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
            } else {
                // display error if unable to save car location
                Toast.makeText(this, "Unable to save car location!",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    /*
     * Method:      retrieveLocation
     * Description: Retrieves the saved car location from SharedPreferences and displays it on the map.
     */
    public void retrieveLocation(View view) {

        // Extracting car coordinates from persistent data
        String value = saved_location.getString("latitude", null);

        if (value == null || value.isEmpty()) {
            Toast.makeText(this, "No car location found!", Toast.LENGTH_SHORT).show();
            return;
        }
        double latitude = Double.parseDouble(value);

        value = saved_location.getString("longitude", null);
        if (value == null || value.isEmpty()) {
            Toast.makeText(this, "No car location found!", Toast.LENGTH_SHORT).show();
            return;
        }
        double longitude = Double.parseDouble(value);

        // Car coordinates object
        LatLng carLocation = new LatLng(latitude, longitude);

        // Add marker for car's location with title and show info window
        Marker carMarker = mMap.addMarker(new MarkerOptions().position(carLocation)
                .title("Car Location"));

        if (carMarker != null) {
            carMarker.showInfoWindow();
        }

//       Getting Current location of user
        LatLng userLocation = null;
        /* Getting User Current Cooridnates */
        int permission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);

        // Gets User Current Location
        if (permission == PackageManager.PERMISSION_GRANTED) {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);

            // display user location marker
            if (location != null) {
                userLocation = new LatLng(location.getLatitude(), location.getLongitude());
            }
        }
        // Add marker for user's location with title
        if (userLocation != null) {
            mMap.addMarker(new MarkerOptions().position(userLocation).title("Your Location"));
        }

//      Calculate the bounds to fit both markers on the screen
        LatLngBounds.Builder builder = new LatLngBounds.Builder();

        if (userLocation != null) {
            builder.include(userLocation);
        }
        builder.include(carLocation);
        LatLngBounds bounds = builder.build();

        // Move camera to show both markers
        mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 600));
    }
}