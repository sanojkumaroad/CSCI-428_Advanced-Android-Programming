/*************************************************
 * CSCI 428      Assignment 4        Spring 2024 *
 *                                               *
 * App Name:    My Car App                       *
 * Class Name:  MainActivity.java                *
 * Developer:   Alyssa Romero (Z1976871)         *
 *              Sanoj Oad (Z1980626)             *
 * Due Date:    04/05/2024                       *
 * Purpose:     This class represents the main   *
 *              activity of the location-based   *
 *              car parking app. It displays a   *
 *              Google Map with the user's       *
 *              current location and provides    *
 *              functionality to save and        *
 *              retrieve a parked car location.  *
 *************************************************/

package edu.niu.android.mycarapp;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Enable edge-to-edge display
        EdgeToEdge.enable(this);

        // Set the layout of the activity
        setContentView(R.layout.activity_main);

        // Apply window insets listener to handle system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            // Get insets for system bars (e.g., status bar, navigation bar)
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());

            // Set padding to adjust for system bars
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

            // Return insets to indicate they have been consumed
            return insets;
        });
    }
}