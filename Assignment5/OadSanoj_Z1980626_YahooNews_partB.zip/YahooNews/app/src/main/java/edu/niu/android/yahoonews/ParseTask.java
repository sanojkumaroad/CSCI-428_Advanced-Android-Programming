package edu.niu.android.yahoonews;


import android.os.AsyncTask;
import android.util.Log;

import java.util.ArrayList;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

/************************************************************************
 * Class Name: ParseTask.java                                           *
 *                                                                      *
 * Purpose: This class is for parsing the rss-feed and sending it to    *
 *          SAXHandler for further handling the items in the list.      *
 ************************************************************************/
public class ParseTask extends AsyncTask<String, Void, ArrayList<Item>> {
    private MainActivity activity;

    // reads the activity for which to parse
    public ParseTask(MainActivity fromActivity) {
        activity = fromActivity;
    }

    // processes the items in the background
    protected ArrayList<Item> doInBackground(String... urls) {
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();
            SAXHandler handler = new SAXHandler();
            saxParser.parse(urls[0], handler);
            return handler.getItems();
        } catch (Exception e) {
            Log.w("MainActivity", e.toString());
            return null;
        }
    }

    // after parsing, displays the list of items
    protected void onPostExecute(ArrayList<Item> returnedItems) {
        activity.displayList(returnedItems);
    }
}