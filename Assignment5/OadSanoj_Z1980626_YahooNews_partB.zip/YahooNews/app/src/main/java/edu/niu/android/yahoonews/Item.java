package edu.niu.android.yahoonews;

/************************************************************************
 * Class Name: Item.java                                                *
 *                                                                      *
 * Purpose: This is the model for the each item in the list for rss-feed*
 ************************************************************************/
public class Item {
    private String title;
    private String link;

    // Constructor to initialize the data
    public Item(String newTitle, String newLink) {
        setTitle(newTitle);
        setLink(newLink);
    }

    // Sets the title of the item
    public void setTitle(String newTitle) {
        title = newTitle;
    }

    // Sets the Link of the item
    public void setLink(String newLink) {
        link = newLink;
    }

    // Gets Title of the item
    public String getTitle() {
        return title;
    }

    // Gets the link of the item
    public String getLink() {
        return link;
    }

    // Returns title + link for item in string form.
    public String toString() {
        return title + "; " + link;
    }
}
