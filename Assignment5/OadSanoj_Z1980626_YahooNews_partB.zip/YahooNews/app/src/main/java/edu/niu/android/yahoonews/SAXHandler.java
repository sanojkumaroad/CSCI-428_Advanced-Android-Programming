package edu.niu.android.yahoonews;


import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/************************************************************************
 * Class Name: SAXHandler.java                                          *
 *                                                                      *
 * Purpose: This class acts as the SAXHandler for our yahoo news app.   *
 *          Handles the item of the list from rss-feed of yahoo news,   *
 *          processes it and finally sends it back to for displaying it *
 ************************************************************************/
public class SAXHandler extends DefaultHandler {
    private boolean validText;
    private String element = "";
    private Item currentItem;
    private ArrayList<Item> items;

    public SAXHandler() {
        validText = false;
        items = new ArrayList<Item>();
    }

    // Gets the items
    public ArrayList<Item> getItems() {
        return items;
    }

    // Creates a new item to process
    public void startElement(String uri, String localName, String startElement, Attributes attributes) throws SAXException {
        validText = true;
        element = startElement;
        if (startElement.equals("item"))
            // start current item
            currentItem = new Item("", "");
    }

    // adds the item to the total list of items
    public void endElement(String uri, String localName, String endElement) throws SAXException {
        validText = false;
        if (endElement.equals("item"))
            // add current item to items
            items.add(currentItem);
    }

    // processes the item here
    public void characters(char ch[], int start, int length) throws SAXException {
        if (currentItem != null && element.equals("title") && validText)
            currentItem.setTitle(new String(ch, start, length));
        else if (currentItem != null && element.equals("link") && validText)
            currentItem.setLink(new String(ch, start, length));
    }
}