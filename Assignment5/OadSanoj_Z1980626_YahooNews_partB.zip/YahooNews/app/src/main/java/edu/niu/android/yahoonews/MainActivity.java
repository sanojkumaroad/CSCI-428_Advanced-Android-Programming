/************************************************************************
 *                                                                      *
 *  CSCI 428                 Assignment 5                   SPRING 2024 *
 *                                                                      *
 * App Name: Yahoo News                                                 *
 *                                                                      *
 * Class Name: MainActivity.java                                        *
 *                                                                      *
 * Developer(s): Sanoj Oad & Alyssa Romero                              *
 *                                                                      *
 * Due Date: 05/03/2024                                                 *
 *                                                                      *
 * Purpose: This Program will uses the Yahoo News RSS feed and lets user*
 *          click on the titles the news articles, upon clicking on the *
 *          item title, it opens the article/link for the user. This    *
 *          program also has a search capability which lets user search *
 *          a term/word to see if that is in the list of items or       *
 *          news articles available on yahoo news.                      *
 *                                                                      *
 ************************************************************************/

package edu.niu.android.yahoonews;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText searchEditText;
    private ListView listView;
    private ArrayList<Item> listItems;
    private final ArrayList<Item> filteredItems = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchEditText = findViewById(R.id.searchEditText);
        listView = findViewById(R.id.list_view);

        // Set up search functionality
        searchEditText.setOnKeyListener((v, keyCode, event) -> {
            if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                filterTitles();
                return true;
            }
            return false;
        });

        // Fetch and parse RSS feed
        fetchAndParseRSS();
    }

    // Fetch and parse RSS feed
    private void fetchAndParseRSS() {
        ParseTask task = new ParseTask(this);
        String URL = "https://www.yahoo.com/news/rss";
        task.execute(URL);
    }

    // Display list of items
    public void displayList(ArrayList<Item> items) {
        listItems = items;
        if (items != null) {
            adapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_list_item_1);
            for (Item item : items) {
                adapter.add(item.getTitle());
            }
            listView.setAdapter(adapter);
            setListItemClickListener(listItems);
        } else {
            Toast.makeText(this, "Sorry - No data found", Toast.LENGTH_LONG).show();
        }
    }

    // Filter titles based on search term
    private void filterTitles() {
        filteredItems.clear(); // Clear previously filtered items
        String searchTerm = searchEditText.getText().toString().toLowerCase().trim();
        if (listItems != null) {
            for (Item item : listItems) {
                if (item.getTitle().toLowerCase().contains(searchTerm)) {
                    filteredItems.add(item);
                }
            }
        }
        displayFilteredTitles();
    }

    // Display filtered titles
    private void displayFilteredTitles() {
        adapter.clear();
        if (!filteredItems.isEmpty()) {
            for (Item item : filteredItems) {
                adapter.add(item.getTitle());
            }
            setListItemClickListener(filteredItems);
        } else {
            Toast.makeText(this, "No matching titles found", Toast.LENGTH_LONG).show();
        }
    }

    // Set item click listener for list view
    private void setListItemClickListener(ArrayList<Item> items) {
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Item selectedItem = items.get(position);
            Uri uri = Uri.parse(selectedItem.getLink());
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(browserIntent);
        });
    }
}
