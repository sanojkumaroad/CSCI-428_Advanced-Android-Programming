/************************************************
 * Class Name: SAXHandler.java                  *
 * Purpose: This class implements 3 methods     *
 *          that read and parse the XML doc     *
 ************************************************/
package edu.niu.android.parta;

import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SAXHandler extends DefaultHandler
{
    private boolean validText;
    private String element = "";
    private Item currentItem;
    private ArrayList<Item> items; //items instance variable

    public SAXHandler()
    {
        validText = false;
        items = new ArrayList<Item>();
    }

    public ArrayList<Item> getItems()
    {
        return items;
    }

     /*******************************************************
     * the startElement() method stores characters within   *
     * a starting tag until an ending tag is encountered.   *
     *******************************************************/
    public void startElement(String uri, String localName,
                             String startElement, Attributes attributes)
            throws SAXException
    {
        validText = true;
        element = startElement;
        if (startElement.equals("item")) // start current item
            currentItem = new Item("", "", "");
    }

     /*******************************************************
     * the endElement() method adds the item to the         *
     * ArrayList items when an ending tag is encountered.   *
     *******************************************************/
    public void endElement(String uri, String localName,
                           String endElement) throws SAXException
    {
        validText = false;
        if (endElement.equals("item")) // add current item to items
            items.add(currentItem);
    }

     /*******************************************************
     * the characters() method determines whether the text  *
     * stored in currentItem is an article title, link, or  *
     * publication date, then uses the set methods of the   *
     * Item class to store them                             *
     *******************************************************/
    public void characters(char ch [], int start,
                           int length) throws SAXException
    {
        if (currentItem != null && element.equals("title") && validText)
            currentItem.setTitle(new String(ch, start, length));
        else if (currentItem != null && element.equals("link") && validText)
            currentItem.setLink(new String(ch, start, length));
        else if (currentItem != null && element.equals("pubDate") && validText)
            currentItem.setPubDate(new String(ch, start, length));
    }
}