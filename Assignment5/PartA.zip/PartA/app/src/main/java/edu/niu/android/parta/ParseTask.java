/************************************************
 * Class Name: ParseTask.java                   *
 * Purpose: This class constructs an ArrayList
 *          of Item objects*
 ************************************************/
package edu.niu.android.parta;

import android.os.AsyncTask;
import android.util.Log;
import java.util.ArrayList;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class ParseTask extends AsyncTask<String, Void, ArrayList<Item>>
{
    private MainActivity activity;

    public ParseTask(MainActivity fromActivity)
    {
        activity = fromActivity;
    }

    /********************************************************
     * the doInBackground() method parses the XML document  *
     ********************************************************/
    protected ArrayList<Item> doInBackground(String... urls)
    {
        try
        {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();
            SAXHandler handler = new SAXHandler();
            saxParser.parse(urls[0], handler);
            return handler.getItems();
        }
        catch (Exception e)
        {
            Log.w("MainActivity", e.toString());
            return null;
        }
    }

    /********************************************************
     * the onPostExecute() method calls the main thread to  *
     * update it                                            *
     *******************************************************/
    protected void onPostExecute (ArrayList<Item> returnedItems)
    {
        activity.displayList(returnedItems);
    }
}
