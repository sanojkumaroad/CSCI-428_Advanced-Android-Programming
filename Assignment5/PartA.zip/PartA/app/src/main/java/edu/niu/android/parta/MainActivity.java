/*************************************************
 * CSCI 428      Assignment 5        Spring 2024 *
 *                                               *
 * App Name: Part A                              *
 * Class Name: MainActivity.java                 *
 * Developer: Alyssa Romero (Z1976871)           *
 *            Sanoj Oad (Z1980626)               *
 * Due Date: 5/3/2024                            *
 * Purpose: The MainActivity class creates the   *
 *          listView of articles and creates an  *
 *          onClick listener for each link       *
 ************************************************/
package edu.niu.android.parta;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
{
    private final String URL = "https://feeds.npr.org/1002/rss.xml"; //URL to NPR rss

    private ListView listView;

    private ArrayList<Item> listItems;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        listView = (ListView) findViewById(R.id.list_view);
        ParseTask task = new ParseTask(this);
        task.execute(URL);
    }

    /*******************************************************
     * the displayList method adds the titles of the       *
     * articles into the listView and sets an onClick      *
     * Listener for each title. If items is null, a toast  *
     * is displayed.                                       *
     *******************************************************/
    public void displayList(ArrayList<Item> items)
    {
        listItems = items;
        if (items != null)
        {
            // Build ArrayList of titles to display
            ArrayList<String> titles = new ArrayList<String>();
            ArrayList<String> dates = new ArrayList<String>();
            for (Item item : items)
            {
                titles.add(item.getTitle());
                dates.add(item.getPubDate());
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1, titles);

            listView.setAdapter(adapter);
            ListItemHandler lih = new ListItemHandler();
            listView.setOnItemClickListener(lih);
        }
        else
            Toast.makeText(this, "Sorry - No data found",
                    Toast.LENGTH_LONG).show();
    }

    /********************************************************
     * the onItemClick method gets the link for the article *
     * displayed and takes the user to that article when    *
     * it is clicked                                        *
     ********************************************************/
    private class ListItemHandler implements AdapterView.OnItemClickListener
    {
        public void onItemClick(AdapterView<?> parent, View view,
                                int position, long id)
        {
            Item selectedItem = listItems.get(position);
            Uri uri = Uri.parse(selectedItem.getLink());
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(browserIntent);
        }
    }
}