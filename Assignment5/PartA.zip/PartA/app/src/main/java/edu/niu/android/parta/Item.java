/************************************************
 * Class Name: Item.java                        *
 * Purpose: This class sets the title, link     *
 *          and pubDate for each item           *
 ************************************************/
package edu.niu.android.parta;

public class Item
{
    private String title; //String for title of article
    private String link; //String for link of article
    private String pubDate; //String for publication date of article

    public Item(String newTitle, String newLink, String newPubDate)
    {
        setTitle(newTitle);
        setLink(newLink);
        setPubDate(newPubDate);
    }

    public void setTitle(String newTitle)
    {
        title = newTitle;
    }

    public void setLink(String newLink)
    {
        link = newLink;
    }

    public void setPubDate(String newPubDate) { pubDate = newPubDate; }

    public String getTitle()
    {
        return title;
    }

    public String getLink()
    {
        return link;
    }

    public String getPubDate() { return pubDate; }

    public String toString()
    {
        return title + "; " + link + ";" + pubDate;
    }
}
